import sys

from azureml.studio.modulehost.module_host_executor import execute


if __name__ == '__main__':
    execute(sys.argv)
